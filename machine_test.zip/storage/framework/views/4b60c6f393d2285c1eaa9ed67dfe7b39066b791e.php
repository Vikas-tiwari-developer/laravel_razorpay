<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Employee</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
<script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>
<style>
    .mt-100 {
    margin-top: 100px
}

body {
    color: #000;
    min-height: 100vh
}
</style>
</head>
<body>

<div class="row d-flex justify-content-center mt-100">
    <div class="col-md-6"> 
        <form action="<?php echo e(route('emp')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <select id="choices-multiple-remove-button" name="company[]" placeholder="Please Select a Company" multiple>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($company); ?>"><?php echo e($company); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </select>
        <button type="submit">Fetch Employee</button> 

</from>

<div class="employee_data">
    <?php if(isset($employee)): ?>
       <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <p><?php echo e($emp->employee_name); ?></p>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
    </div>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function(){

        var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
        removeItemButton: true,
        maxItemCount:5,
        searchResultLimit:5,
        renderChoiceLimit:5
    });


});
</script>
</body>
</html>


<?php /**PATH C:\laragon\www\machine_test\resources\views/task_1/company.blade.php ENDPATH**/ ?>